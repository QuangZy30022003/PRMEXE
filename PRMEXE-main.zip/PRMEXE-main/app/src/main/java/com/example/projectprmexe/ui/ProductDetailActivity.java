package com.example.projectprmexe.ui;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.projectprmexe.R;
import com.example.projectprmexe.data.api.ProductAPI;
import com.example.projectprmexe.data.model.Product.ProductDto;
import com.example.projectprmexe.data.model.Product.ProductImageDto;
import com.example.projectprmexe.data.repository.ProductInstance;
import com.example.projectprmexe.ui.adapter.ProductImageAdapter;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductDetailActivity extends AppCompatActivity {

    private ImageView imgMainProduct;
    private TextView txtName, txtDescription, txtPrice, txtAvailability, txtCreatedAt, txtCategoryId;
    private RecyclerView recyclerImages;
    private ProductImageAdapter imageAdapter;
    private List<ProductImageDto> imageList = new ArrayList<>();
    
    private int productId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        // Get product ID from intent
        productId = getIntent().getIntExtra("product_id", -1);
        if (productId == -1) {
            Toast.makeText(this, "Lỗi: Không tìm thấy sản phẩm", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        initViews();
        setupImageRecyclerView();
        loadProductDetail();
    }

    private void initViews() {
        imgMainProduct = findViewById(R.id.imgMainProduct);
        txtName = findViewById(R.id.txtDetailProductName);
        txtDescription = findViewById(R.id.txtDetailProductDescription);
        txtPrice = findViewById(R.id.txtDetailProductPrice);
        txtAvailability = findViewById(R.id.txtDetailProductAvailability);
        txtCreatedAt = findViewById(R.id.txtDetailProductCreatedAt);
        txtCategoryId = findViewById(R.id.txtDetailProductCategory);
        recyclerImages = findViewById(R.id.recyclerProductImages);
    }

    private void setupImageRecyclerView() {
        imageAdapter = new ProductImageAdapter(imageList);
        recyclerImages.setAdapter(imageAdapter);
        recyclerImages.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
    }

    private void loadProductDetail() {
        Toast.makeText(this, "🔄 Loading product ID: " + productId, Toast.LENGTH_SHORT).show();
        
        ProductAPI api = ProductInstance.getApiService();
        api.getProductById(productId).enqueue(new Callback<ProductDto>() {
            @Override
            public void onResponse(Call<ProductDto> call, Response<ProductDto> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Toast.makeText(ProductDetailActivity.this, "✅ Loaded: " + response.body().getName(), Toast.LENGTH_SHORT).show();
                    displayProductDetail(response.body());
                } else {
                    Toast.makeText(ProductDetailActivity.this, "❌ API Error: " + response.code(), Toast.LENGTH_LONG).show();
                    // Load sample data for testing
                    loadSampleData();
                }
            }

            @Override
            public void onFailure(Call<ProductDto> call, Throwable t) {
                Toast.makeText(ProductDetailActivity.this, "💥 Connection Error: " + t.getMessage(), Toast.LENGTH_LONG).show();
                // Load sample data for testing
                loadSampleData();
            }
        });
    }

    private void displayProductDetail(ProductDto product) {
        txtName.setText(product.getName());
        txtDescription.setText(product.getDescription() != null ? product.getDescription() : "Không có mô tả");
        txtPrice.setText(product.getFormattedPrice());
        txtCategoryId.setText("Danh mục: " + product.getCategoryId());

        // Set availability
        if (product.isAvailable()) {
            txtAvailability.setText("Còn hàng");
            txtAvailability.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        } else {
            txtAvailability.setText("Hết hàng");
            txtAvailability.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        }

        // Display created date as string
        if (product.getCreatedAt() != null && !product.getCreatedAt().isEmpty()) {
            txtCreatedAt.setText("Ngày tạo: " + product.getCreatedAt());
        } else {
            txtCreatedAt.setText("Ngày tạo: Không có thông tin");
        }

        // Set main image using Glide
        String mainImageUrl = product.getFirstImageUrl();
        System.out.println("Loading main image for " + product.getName() + ": " + mainImageUrl);
        if (mainImageUrl != null && !mainImageUrl.isEmpty() && !mainImageUrl.equals("sample_image_url")) {
            Glide.with(this)
                    .load(mainImageUrl)
                    .placeholder(R.drawable.image_placeholder)
                    .error(R.drawable.image_placeholder)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(imgMainProduct);
        } else {
            // Use placeholder for sample/empty URLs
            imgMainProduct.setImageResource(R.drawable.image_placeholder);
        }

        // Load additional images
        if (product.getImages() != null && !product.getImages().isEmpty()) {
            imageList.clear();
            imageList.addAll(product.getImages());
            imageAdapter.notifyDataSetChanged();
        }
    }

    private void loadSampleData() {
        // Sample data for testing
        ProductDto sampleProduct = new ProductDto(productId, "Hoa Hồng Đỏ", 
            "Hoa hồng đỏ tươi đẹp, thích hợp làm quà tặng cho người thân yêu. Được trồng trong điều kiện tự nhiên, đảm bảo chất lượng tốt nhất.", 
            50000, "sample_image_url", true);
        
        // Add sample images
        List<ProductImageDto> sampleImages = new ArrayList<>();
        sampleImages.add(new ProductImageDto(1, "sample_image_1"));
        sampleImages.add(new ProductImageDto(2, "sample_image_2"));
        sampleImages.add(new ProductImageDto(3, "sample_image_3"));
        sampleProduct.setImages(sampleImages);
        
        displayProductDetail(sampleProduct);
    }
}